package com.acusmin2020.calculator.operation.base

open class UnaryOperation protected constructor(protected var value: Double)
