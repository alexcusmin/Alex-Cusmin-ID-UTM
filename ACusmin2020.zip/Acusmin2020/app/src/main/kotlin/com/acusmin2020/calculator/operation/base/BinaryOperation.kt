package com.acusmin2020.calculator.operation.base

open class BinaryOperation protected constructor(protected var baseValue: Double, protected var secondValue: Double)
