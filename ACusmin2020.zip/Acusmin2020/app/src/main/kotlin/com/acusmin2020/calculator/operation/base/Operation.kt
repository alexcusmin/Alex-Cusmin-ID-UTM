package com.acusmin2020.calculator.operation.base

interface Operation {
    fun getResult(): Double
}
